#include "raycast.h"

// Add any code you need here and in the corresponding header
// file.


Sphere::Sphere()
{

}



Sphere::Sphere(Vec3f centre, float radius, Vec3f color)
{

}


bool Sphere::intersect(const Ray &r, Hit &h)
{

}
